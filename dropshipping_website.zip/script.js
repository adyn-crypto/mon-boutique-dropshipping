
let panier = [];

function ajouterAuPanier(produit) {
    panier.push(produit);
    alert(produit + " a été ajouté au panier !");
    console.log("Panier actuel : ", panier);
}

async function obtenirProduits() {
    try {
        const response = await fetch('https://api.spocket.co/v1/products', {
            headers: {
                'Authorization': 'Bearer TON_API_KEY'
            }
        });
        const data = await response.json();
        afficherProduits(data.products);
    } catch (error) {
        console.error('Erreur lors de la récupération des produits:', error);
    }
}

function afficherProduits(produits) {
    const container = document.getElementById('produits');
    produits.forEach(produit => {
        const produitElement = document.createElement('div');
        produitElement.className = 'produit';
        produitElement.innerHTML = `
            <img src="${produit.image}" alt="${produit.title}">
            <h3>${produit.title}</h3>
            <p>${produit.description}</p>
            <p>Prix : ${produit.price} €</p>
            <button onclick="ajouterAuPanier('${produit.title}')">Ajouter au panier</button>
        `;
        container.appendChild(produitElement);
    });
}

// Exemple d'utilisation : obtenirProduits();
